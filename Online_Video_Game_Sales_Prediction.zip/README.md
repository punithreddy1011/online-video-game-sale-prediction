# Online Video Game Sales Prediction

This project predicts video game sales using machine learning (Random Forest) based on historical sales data, genres, and platforms.

## Project Structure
- **data/** : Contains the dataset (e.g., `vgsales.csv`).
- **notebooks/** : Jupyter notebooks for EDA and model training.
- **src/** : Source code for data preprocessing, model training, and prediction.
- **visualizations/** : Generated charts and plots.

## Steps to Run
1. Clone the repository.
2. Install required dependencies using `pip install -r requirements.txt`.
3. Run `src/train_model.py` to train the model.
4. Use `src/predict.py` to predict sales for new games.

## Tech Stack
- Python 3.x
- Pandas, NumPy
- Scikit-learn
- Matplotlib, Seaborn, Plotly
